module LogoutHelper
end
